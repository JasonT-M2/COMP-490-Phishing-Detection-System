from __future__ import annotations

from dataclasses import asdict, dataclass
from email import policy
from email.parser import BytesParser
from email.utils import parseaddr
import re


@dataclass
class Reason:
    id: str
    severity: str
    message: str
    evidence: dict


def _safe_lower(value: str | None) -> str:
    return (value or "").strip().lower()


def extract_domain(addr: str) -> str:
    _, email_addr = parseaddr(addr or "")
    email_addr = email_addr.strip()
    if "@" not in email_addr:
        return ""
    return email_addr.split("@", 1)[1].lower().strip()


def extract_display_name(addr: str) -> str:
    name, _ = parseaddr(addr or "")
    return (name or "").strip()


def clamp01(value: float) -> float:
    return 0.0 if value < 0 else 1.0 if value > 1.0 else value


def score_to_tier(score: float) -> str:
    if score >= 0.75:
        return "HIGH"
    if score >= 0.40:
        return "MED"
    return "LOW"


def parse_auth_results_blob(blob: str) -> dict:
    blob_lower = _safe_lower(blob)
    out: dict[str, str] = {}

    def find_result(token: str) -> str:
        match = re.search(rf"\b{token}\s*=\s*([a-z0-9_-]+)", blob_lower)
        return match.group(1) if match else ""

    for key in ("spf", "dkim", "dmarc"):
        result = find_result(key)
        if result:
            out[key] = result

    match_from = re.search(r"\bheader\.from\s*=\s*([a-z0-9.\-]+)", blob_lower)
    if match_from:
        out["header.from"] = match_from.group(1)

    match_mailfrom = re.search(
        r"\b(smtp\.mailfrom|mailfrom)\s*=\s*([a-z0-9._%+\-]+@[a-z0-9.\-]+)",
        blob_lower,
    )
    if match_mailfrom:
        out["smtp.mailfrom"] = match_mailfrom.group(2)

    return out


def normalize_auth_result(result: str) -> str:
    result = _safe_lower(result)
    mapping = {"bestguesspass": "pass"}
    return mapping.get(result, result)


def domains_mismatch(d1: str, d2: str) -> bool:
    left = _safe_lower(d1)
    right = _safe_lower(d2)
    return bool(left) and bool(right) and left != right


def is_external(domain: str, internal_domains: list[str]) -> bool:
    value = _safe_lower(domain)
    return bool(value) and all(not value.endswith(internal) for internal in internal_domains)


def compute_content_risk(email_text: str) -> list[Reason]:
    """Fallback/explainability signals when full raw headers are not available."""
    text = _safe_lower(email_text)
    reasons: list[Reason] = []

    def add(rid: str, severity: str, message: str, evidence: dict):
        reasons.append(Reason(rid, severity, message, evidence))

    if re.search(r"\b(urgent|immediately|act now|asap|final notice)\b", text):
        add(
            "URGENT_LANGUAGE",
            "MED",
            "Urgency or pressure language was detected.",
            {"matched_pattern": "urgent / immediately / act now / final notice"},
        )

    if re.search(r"\b(verify your account|confirm your password|reset your password|login now)\b", text):
        add(
            "CREDENTIAL_LANGUAGE",
            "HIGH",
            "Credential-request language was detected.",
            {"matched_pattern": "verify account / password / login"},
        )

    if re.search(r"\b(gift card|wire transfer|bitcoin|crypto)\b", text):
        add(
            "PAYMENT_SCAM_LANGUAGE",
            "HIGH",
            "Common scam payment language was detected.",
            {"matched_pattern": "gift card / wire transfer / crypto"},
        )

    urls = re.findall(r"https?://[^\s)>'\"]+", email_text or "", flags=re.IGNORECASE)
    if len(urls) >= 3:
        add(
            "MULTIPLE_LINKS",
            "LOW",
            "Multiple links were detected.",
            {"url_count": len(urls)},
        )

    suspicious_tld_urls = [
        url for url in urls if re.search(r"\.(ru|tk|xyz|top|click|gq)(/|\b)", url, flags=re.IGNORECASE)
    ]
    if suspicious_tld_urls:
        add(
            "SUSPICIOUS_TLD",
            "MED",
            "A link uses a commonly abused or suspicious top-level domain.",
            {"example": suspicious_tld_urls[0]},
        )

    return reasons


def compute_header_risk_from_raw_text(
    raw_email_text: str,
    internal_domains: list[str] | None = None,
    exec_names: list[str] | None = None,
) -> dict:
    """Analyze raw email headers plus message content and return explainable risk."""
    internal_domains = [domain.lower().strip() for domain in (internal_domains or []) if domain.strip()]
    exec_names = [name.strip() for name in (exec_names or []) if name.strip()]

    if not internal_domains:
        internal_domains = ["company.com"]

    raw_email_text = raw_email_text or ""
    raw_bytes = raw_email_text.encode("utf-8", errors="replace")

    try:
        message = BytesParser(policy=policy.default).parsebytes(raw_bytes)

        from_header = (message.get("From") or "").strip()
        reply_to_header = (message.get("Reply-To") or "").strip()
        return_path_header = (message.get("Return-Path") or "").strip()

        auth_lines = []
        for header_name in ["Authentication-Results", "ARC-Authentication-Results", "Received-SPF"]:
            for value in message.get_all(header_name, []):
                if isinstance(value, str) and value.strip():
                    auth_lines.append(value.strip())
        auth_blob = "\n".join(auth_lines)
    except Exception:
        def grab(name: str) -> str:
            match = re.search(
                rf"^{re.escape(name)}:\s*(.+)$",
                raw_email_text,
                flags=re.MULTILINE | re.IGNORECASE,
            )
            return match.group(1).strip() if match else ""

        from_header = grab("From")
        reply_to_header = grab("Reply-To")
        return_path_header = grab("Return-Path")
        auth_blob = "\n".join([
            grab("Authentication-Results"),
            grab("ARC-Authentication-Results"),
            grab("Received-SPF"),
        ]).strip()

    from_domain = extract_domain(from_header)
    reply_domain = extract_domain(reply_to_header) if reply_to_header else ""
    return_path_domain = extract_domain(return_path_header)
    display_name = extract_display_name(from_header)
    display_name_norm = _safe_lower(display_name)

    auth = parse_auth_results_blob(auth_blob)
    spf = normalize_auth_result(auth.get("spf", ""))
    dkim = normalize_auth_result(auth.get("dkim", ""))
    dmarc = normalize_auth_result(auth.get("dmarc", ""))

    score = 0.0
    reasons: list[Reason] = []

    def add(rid: str, severity: str, message: str, evidence: dict, delta: float):
        nonlocal score
        reasons.append(Reason(rid, severity, message, evidence))
        score += delta

    if dmarc in ("fail", "permerror"):
        add(
            "DMARC_FAIL",
            "HIGH",
            "DMARC failed for this message.",
            {"dmarc": dmarc, "Authentication-Results": auth_blob[:500]},
            0.45,
        )
    elif dmarc and dmarc not in ("pass", "none"):
        add(
            "DMARC_SUSPICIOUS",
            "MED",
            f"DMARC is {dmarc}.",
            {"dmarc": dmarc, "Authentication-Results": auth_blob[:500]},
            0.20,
        )

    if spf in ("fail", "softfail", "permerror"):
        add(
            "SPF_FAIL",
            "MED" if spf == "softfail" else "HIGH",
            f"SPF is {spf}.",
            {"spf": spf, "Authentication-Results": auth_blob[:500]},
            0.25 if spf == "softfail" else 0.35,
        )

    if dkim in ("fail", "permerror"):
        add(
            "DKIM_FAIL",
            "HIGH",
            f"DKIM is {dkim}.",
            {"dkim": dkim, "Authentication-Results": auth_blob[:500]},
            0.30,
        )

    header_from_domain = _safe_lower(auth.get("header.from", "")) or from_domain
    smtp_mailfrom_domain = extract_domain(auth.get("smtp.mailfrom", ""))
    if header_from_domain and smtp_mailfrom_domain and domains_mismatch(header_from_domain, smtp_mailfrom_domain):
        add(
            "FROM_MAILFROM_MISMATCH",
            "MED",
            "Header From domain differs from SMTP MAIL FROM domain.",
            {"header.from": header_from_domain, "smtp.mailfrom": auth.get("smtp.mailfrom", "")},
            0.18,
        )

    if reply_domain and from_domain and domains_mismatch(reply_domain, from_domain):
        add(
            "REPLY_TO_MISMATCH",
            "HIGH",
            "Reply-To domain differs from From domain.",
            {"From": from_header, "Reply-To": reply_to_header},
            0.35,
        )

    exec_norm = {_safe_lower(name) for name in exec_names if name.strip()}
    if exec_norm and display_name_norm and display_name_norm in exec_norm and is_external(from_domain, internal_domains):
        add(
            "DISPLAY_NAME_SPOOF",
            "HIGH",
            "Sender display name matches a trusted/internal name, but the sender domain is external.",
            {"Display-Name": display_name, "From": from_header, "From-Domain": from_domain},
            0.40,
        )

    if return_path_domain and from_domain and domains_mismatch(return_path_domain, from_domain):
        add(
            "RETURN_PATH_MISMATCH",
            "MED",
            "Return-Path domain differs from From domain.",
            {"From": from_header, "Return-Path": return_path_header},
            0.15,
        )

    if dmarc == "pass" and spf == "pass" and dkim == "pass":
        score -= 0.10

    # Add content-based explainability signals when full headers are absent or minimal.
    content_reasons = compute_content_risk(raw_email_text)
    for reason in content_reasons:
        reasons.append(reason)
        if reason.severity == "HIGH":
            score += 0.20
        elif reason.severity == "MED":
            score += 0.12
        else:
            score += 0.06

    score = clamp01(score)

    extracted = {
        "From": from_header,
        "From-Domain": from_domain,
        "Reply-To": reply_to_header,
        "Reply-To-Domain": reply_domain,
        "Return-Path": return_path_header,
        "Return-Path-Domain": return_path_domain,
        "Display-Name": display_name,
        "spf": spf,
        "dkim": dkim,
        "dmarc": dmarc,
    }

    return {
        "header_risk_score": score,
        "tier": score_to_tier(score),
        "reasons": [asdict(reason) for reason in reasons],
        "extracted": extracted,
    }
