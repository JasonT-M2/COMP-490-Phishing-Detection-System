from __future__ import annotations

import os


os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")

from pathlib import Path
import pickle
from typing import Iterable

import numpy as np
import tensorflow as tf

from config import MODEL_CANDIDATES, PROJECT_ROOT, VECTORIZER_CANDIDATES


def resolve_existing_path(candidates: Iterable[str]) -> Path:
    checked: list[str] = []
    backend_dir = Path(__file__).resolve().parent

    for name in candidates:
        for path in (PROJECT_ROOT / name, backend_dir / name):
            checked.append(str(path))
            if path.exists():
                return path

    raise FileNotFoundError(
        "Could not find required asset. Checked:\n" + "\n".join(checked)
    )


class ModelService:
    """Loads the TF-IDF vectorizer and Keras model once, then reuses them."""

    def __init__(self) -> None:
        self._vectorizer = None
        self._model = None
        self._vectorizer_path: Path | None = None
        self._model_path: Path | None = None
        self._validated = False

    @property
    def vectorizer(self):
        if self._vectorizer is None:
            self._vectorizer_path = resolve_existing_path(VECTORIZER_CANDIDATES)
            with open(self._vectorizer_path, "rb") as handle:
                self._vectorizer = pickle.load(handle)
        return self._vectorizer

    @property
    def model(self):
        if self._model is None:
            self._model_path = resolve_existing_path(MODEL_CANDIDATES)
            self._model = tf.keras.models.load_model(self._model_path)
        return self._model

    def validate_assets(self) -> dict:
        """Confirm that the vectorizer output size matches model input size."""
        vectorizer = self.vectorizer
        model = self.model

        expected_dim = int(model.input_shape[-1])

        if hasattr(vectorizer, "get_feature_names_out"):
            actual_dim = int(len(vectorizer.get_feature_names_out()))
        elif hasattr(vectorizer, "vocabulary_"):
            actual_dim = int(len(vectorizer.vocabulary_))
        else:
            sample = vectorizer.transform(["test"]).toarray()
            actual_dim = int(sample.shape[1])

        if expected_dim != actual_dim:
            raise ValueError(
                "Model/vectorizer mismatch: "
                f"model expects {expected_dim} features, "
                f"but vectorizer provides {actual_dim}. "
                "Use a model and vectorizer saved from the same training run."
            )

        self._validated = True
        return {
            "status": "ok",
            "model_path": str(self._model_path),
            "vectorizer_path": str(self._vectorizer_path),
            "model_expected_features": expected_dim,
            "vectorizer_output_features": actual_dim,
        }

    def predict_text(self, email_text: str) -> dict:
        email_text = (email_text or "").strip()
        if not email_text:
            return {
                "prediction_label": "Unknown",
                "prediction_prob": 0.0,
            }

        if not self._validated:
            self.validate_assets()

        features = self.vectorizer.transform([email_text]).toarray().astype(np.float32)
        prediction = self.model.predict(features, verbose=0)

        probability = float(prediction[0][0])
        label = "Phishing" if probability >= 0.5 else "Safe"

        return {
            "prediction_label": label,
            "prediction_prob": probability,
        }
