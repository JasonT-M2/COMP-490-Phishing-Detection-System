from __future__ import annotations

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BASE_DIR.parent


MODEL_CANDIDATES = [
    "phishing_model.keras",
    "phishing_model(2).keras",
]

VECTORIZER_CANDIDATES = [
    "tfidf_vectorizer.pkl",
    "tfidf_vectorizer(2).pkl",
]


INTERNAL_DOMAINS = [
    "company.com",
    "school.edu",
]

EXEC_NAMES = []
