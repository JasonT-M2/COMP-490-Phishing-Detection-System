from __future__ import annotations

from flask import Flask, jsonify, render_template, request
from flask_cors import CORS

from config import EXEC_NAMES, INTERNAL_DOMAINS
from header_risk import compute_header_risk_from_raw_text
from model_service import ModelService

app = Flask(__name__)
CORS(app)

model_service = ModelService()


def combine_email_and_headers(email_text: str, header_text: str) -> str:
    email_text = (email_text or "").strip()
    header_text = (header_text or "").strip()

    if email_text and header_text:
        return f"{header_text}\n\n{email_text}"
    return header_text or email_text


def get_request_text() -> tuple[str, str]:
    """Support both website form posts and Chrome extension JSON posts."""
    if request.is_json:
        payload = request.get_json(silent=True) or {}
        email_text = str(payload.get("email_text", ""))
        header_text = str(payload.get("header_text", ""))
    else:
        email_text = str(request.form.get("email_text", ""))
        header_text = str(request.form.get("header_text", ""))

    return email_text, header_text


def build_prediction_response(email_text: str, header_text: str) -> dict:
    combined_text = combine_email_and_headers(email_text, header_text)

    if not combined_text.strip():
        raise ValueError("Provide email_text and/or header_text.")

    # ML model should predict from the body/content. If body is empty, fall back
    # to combined text so the endpoint still works with pasted raw email.
    ml_input = email_text.strip() or combined_text

    ml_result = model_service.predict_text(ml_input)

    header_risk = compute_header_risk_from_raw_text(
        combined_text,
        internal_domains=INTERNAL_DOMAINS,
        exec_names=EXEC_NAMES,
    )

    return {
        **ml_result,
        "header_risk": header_risk,
    }


@app.get("/")
def home():
    return render_template(
        "index.html",
        prediction_label=None,
        prediction_prob=None,
        header_risk=None,
    )


@app.get("/health")
def health():
    return jsonify({"status": "ok"})


@app.get("/debug/assets")
def debug_assets():
    """Open this in the browser to verify the model/vectorizer pair."""
    try:
        return jsonify(model_service.validate_assets())
    except Exception as exc:
        return jsonify({"status": "error", "error": str(exc)}), 500


@app.post("/predict")
def predict():
    try:
        email_text, header_text = get_request_text()
        response = build_prediction_response(email_text, header_text)

        if request.is_json:
            return jsonify(response)

        return render_template(
            "index.html",
            prediction_label=response["prediction_label"],
            prediction_prob=response["prediction_prob"],
            header_risk=response["header_risk"],
        )

    except Exception as exc:
        error_response = {
            "prediction_label": "Error",
            "prediction_prob": 0.0,
            "header_risk": {
                "tier": "ERROR",
                "header_risk_score": 0.0,
                "reasons": [
                    {
                        "id": "SERVER_ERROR",
                        "severity": "HIGH",
                        "message": str(exc),
                        "evidence": {},
                    }
                ],
                "extracted": {},
            },
            "error": str(exc),
        }

        if request.is_json:
            return jsonify(error_response), 500

        return render_template(
            "index.html",
            prediction_label=error_response["prediction_label"],
            prediction_prob=error_response["prediction_prob"],
            header_risk=error_response["header_risk"],
        ), 500


@app.get("/about")
def about():
    return render_template("about.html")


@app.get("/docs")
def docs():
    return render_template("documentation.html")


@app.get("/security-tips")
def security_tips():
    return render_template("tips.html")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
