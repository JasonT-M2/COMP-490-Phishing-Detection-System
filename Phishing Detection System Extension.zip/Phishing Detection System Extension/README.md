# Chrome Extension System

## Folder structure
- `backend/` Flask app and templates
- `extension/` Chrome extension files

## Required model assets
Place these model filenames in the project root:
- `phishing_model.keras` 
- `tfidf_vectorizer.pkl` 

The backend automatically searches for those names.

## Run locally
python app.py


Then in Chrome:
1. open `chrome://extensions`
2. enable Developer mode
3. choose Load unpacked
4. select the `extension/` folder





