const emailTextEl = document.getElementById("emailText");
const headerTextEl = document.getElementById("headerText");
const resultCard = document.getElementById("resultCard");
const predictionLabelEl = document.getElementById("predictionLabel");
const predictionProbEl = document.getElementById("predictionProb");
const headerTierEl = document.getElementById("headerTier");
const headerScoreEl = document.getElementById("headerScore");
const reasonsListEl = document.getElementById("reasonsList");
const backendStatusEl = document.getElementById("backendStatus");

const BACKEND_URL = "http://127.0.0.1:5000";

document.addEventListener("DOMContentLoaded", () => {
  checkBackend();
});

document.getElementById("clearBtn").addEventListener("click", () => {
  emailTextEl.value = "";
  headerTextEl.value = "";
  resultCard.classList.add("hidden");
});

document.getElementById("loadPageBtn").addEventListener("click", async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const response = await chrome.tabs.sendMessage(tab.id, { action: "extract_email_context" });

    if (!response) {
      alert("Could not read content from this page.");
      return;
    }

    emailTextEl.value = response.emailText || "";
    headerTextEl.value = response.headerText || "";
  } catch (error) {
    console.error(error);
    alert("Could not extract page content. Try pasting the email manually.");
  }
});

document.getElementById("scanBtn").addEventListener("click", async () => {
  const emailText = emailTextEl.value.trim();
  const headerText = headerTextEl.value.trim();

  if (!emailText && !headerText) {
    alert("Provide email text and/or raw headers first.");
    return;
  }

  try {
    const response = await fetch(`${BACKEND_URL}/predict`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email_text: emailText,
        header_text: headerText
      })
    });

    const data = await response.json();

    if (!response.ok) {
      renderResult(data);
      throw new Error(data.error || `Request failed with ${response.status}`);
    }

    renderResult(data);
  } catch (error) {
    console.error(error);
    if (!resultCard.classList.contains("hidden")) {
      return;
    }
    alert("Could not reach the backend. Start backend/app.py first.");
  }
});

async function checkBackend() {
  try {
    const response = await fetch(`${BACKEND_URL}/health`);
    if (!response.ok) throw new Error("Backend health check failed.");
    backendStatusEl.textContent = "Backend connected";
    backendStatusEl.className = "status ok";
  } catch {
    backendStatusEl.textContent = "Backend not connected";
    backendStatusEl.className = "status error";
  }
}

function renderResult(data) {
  resultCard.classList.remove("hidden", "risk-low", "risk-med", "risk-high", "risk-error");

  const tier = data.header_risk?.tier || "N/A";
  resultCard.classList.add(`risk-${tier.toLowerCase()}`);

  predictionLabelEl.textContent = data.prediction_label || "Unknown";
  predictionProbEl.textContent = formatPercent(data.prediction_prob);
  headerTierEl.textContent = tier;
  headerScoreEl.textContent = formatPercent(data.header_risk?.header_risk_score);

  reasonsListEl.innerHTML = "";
  const reasons = data.header_risk?.reasons || [];

  if (!reasons.length) {
    const item = document.createElement("li");
    item.textContent = "No header-based warning signals were found.";
    reasonsListEl.appendChild(item);
    return;
  }

  reasons.forEach((reason) => {
    const item = document.createElement("li");
    item.className = `severity-${(reason.severity || "LOW").toLowerCase()}`;

    const evidencePairs = Object.entries(reason.evidence || {})
      .filter(([, value]) => value !== null && value !== undefined && String(value).length > 0)
      .map(([key, value]) => `${key}: ${value}`)
      .join(" | ");

    item.textContent = `[${reason.severity || "LOW"}] ${reason.message}${evidencePairs ? " — " + evidencePairs : ""}`;
    reasonsListEl.appendChild(item);
  });
}

function formatPercent(value) {
  const n = Number(value);
  if (Number.isNaN(n)) return "N/A";
  return `${(n * 100).toFixed(2)}%`;
}
