function pickText(selectors) {
  for (const selector of selectors) {
    const el = document.querySelector(selector);
    if (el && el.innerText && el.innerText.trim().length > 40) {
      return el.innerText.trim();
    }
  }
  return "";
}

function extractEmailContext() {
  const emailText = pickText([
    ".a3s",
    ".ii.gt",
    "[role='main']",
    "[data-app-section='MailReadCompose']",
    "article",
    "main",
    "body"
  ]).slice(0, 16000);

  return {
    emailText,
    headerText: ""
  };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extract_email_context") {
    sendResponse(extractEmailContext());
  }
});
