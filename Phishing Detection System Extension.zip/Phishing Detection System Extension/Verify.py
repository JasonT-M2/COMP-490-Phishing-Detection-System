import pickle
import tensorflow as tf

with open("tfidf_vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

model = tf.keras.models.load_model("phishing_model.keras")

print("Model expects:", model.input_shape[-1])
print("Vectorizer outputs:", len(vectorizer.get_feature_names_out()))